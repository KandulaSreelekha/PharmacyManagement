import React from 'react';

const Customer = () => {
  return (
    <div>
      <h2>Customer Management</h2>
      <p>This is the customer management page.</p>
    </div>
  );
};

export default Customer;