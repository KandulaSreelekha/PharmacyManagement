import React from 'react';

const Stock = () => {
  return (
    <div>
      <h2>Stock Management</h2>
      <p>This is the stock management page.</p>
    </div>
  );
};

export default Stock;