import React from 'react';

const Invoice = () => {
  return (
    <div>
      <h2>Invoice Management</h2>
      <p>This is the invoice management page.</p>
    </div>
  );
};

export default Invoice;