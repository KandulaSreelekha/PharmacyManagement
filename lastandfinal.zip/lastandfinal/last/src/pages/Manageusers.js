import React from "react";

const ManageUsers = () => {
  return <h2>Manage Users (Admin Only)</h2>;
};

export default ManageUsers;
